document.getElementById("rsvpForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const hadir = document.querySelector('input[name="hadir"]:checked').value;
  const jumlah = document.getElementById("jumlah").value || "0";
  document.getElementById("rsvpResult").innerHTML = `<p>Terima kasih atas jawapan anda: <strong>${hadir}</strong> (${jumlah} tetamu)</p>`;
  this.reset();
});

document.getElementById("ucapanForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const ucapan = document.getElementById("ucapanText").value;
  const list = document.getElementById("ucapanList");
  const newItem = document.createElement("p");
  newItem.textContent = `📝 ${ucapan}`;
  list.prepend(newItem);
  this.reset();
});
